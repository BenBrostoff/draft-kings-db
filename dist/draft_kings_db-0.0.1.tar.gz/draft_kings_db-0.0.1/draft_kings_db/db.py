def hi():
    print('hi')
